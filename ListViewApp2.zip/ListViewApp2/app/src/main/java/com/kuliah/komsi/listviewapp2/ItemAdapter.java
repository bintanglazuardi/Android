package com.kuliah.komsi.listviewapp2;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ViewHolder> {
    private Context context;
    private ArrayList<ItemData> values = new ArrayList<>();
    private LayoutInflater inflater;
    public ItemAdapter(Context context, ArrayList<ItemData> values){
        this.context = context;
        this.values = values;
        this.inflater = LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = inflater.inflate(R.layout.item_list, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder viewHolder, int position) {
        final ItemData data = values.get(position);
        viewHolder.username.setText(data.itemNama);
        viewHolder.email.setText(data.itemTelepon);
        
        viewHolder.itemView.setOnClickListener(
                new View.OnClickListener(){
                    public void onClick(View view){
                        Toast.makeText(context, "" + data.itemNama, Toast.LENGTH_SHORT).show();
                    }
                }
        );

        viewHolder.itemView.setOnLongClickListener(
                new View.OnLongClickListener(){
                    @Override
                    public boolean onLongClick(View view) {
                        //untuk menampilkan pop up ketika list ditekan dan tahan
                        AlertDialog.Builder builder = new AlertDialog.Builder(view.getRootView().getContext());
                        builder.setTitle("Hapus Data");
                        builder
                                .setMessage("Apakah Anda yakin ingin menghapus data ini ?")
                                .setPositiveButton("Batal", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        dialogInterface.cancel();
                                    }
                                })
                                .setNegativeButton("Hapus", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        values.remove(data);
                                        notifyDataSetChanged();
                                        Toast.makeText(context, "Anda menghapus " + data.itemNama, Toast.LENGTH_SHORT).show();
                                    }
                                });

                        AlertDialog dialog = builder.create();
                        dialog.show();

                        return false;
                    }
                }
        );
        
    }

    @Override
    public int getItemCount() {
        return values.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView username;
        TextView email;
        public ViewHolder(View view){
            super(view);
            username = view.findViewById(R.id.nama);    //dari item_list
            email = view.findViewById(R.id.telepon);
        }
    }
}
