package com.kuliah.komsi.listviewapp2;

public class ItemData {
    public String itemNama;
    public String itemTelepon;

}
