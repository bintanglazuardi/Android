package com.kuliah.komsi.listviewapp2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private ArrayList<ItemData> itemValues = new ArrayList<>();
    private ItemAdapter itemAdapter;
    EditText nama, telepon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        nama = findViewById(R.id.inputNama);
        telepon = findViewById(R.id.inputTelepon);

        //menampilkan list 1-10
        for (int i=1; i<=10; i++){
            ItemData item = new ItemData();
            item.itemNama = "Nama - " + i ;
            item.itemTelepon = "08127384731" + i ;
            itemValues.add(item);
        }
        itemAdapter = new ItemAdapter(this,itemValues);

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));      //menampilkan mode grid 2 kolom
        recyclerView.setAdapter(itemAdapter);
    }

    //menampilkan ikon menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    // melakukan eksekusi ikon menu
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        Toast.makeText(this, "Tekan dan tahan kontak untuk menghapus data", Toast.LENGTH_SHORT).show();
        return super.onOptionsItemSelected(item);
    }

    //menambahkan data
    public void addData(View view) {
        boolean isEmptyFields = false;
        ItemData item = new ItemData();
        item.itemNama = nama.getText().toString();
        item.itemTelepon = telepon.getText().toString();

        if (TextUtils.isEmpty(item.itemNama)){
            isEmptyFields = true;
            nama.setError("Field ini tidak boleh kosong !");
        }
        if (TextUtils.isEmpty(item.itemTelepon)){
            isEmptyFields = true;
            telepon.setError("Field ini tidak boleh kosong !");
        }
        if (!isEmptyFields){
            itemValues.add(item);
            itemAdapter.notifyDataSetChanged();
            Toast.makeText(this, "Anda menambahkan data " + item.itemNama, Toast.LENGTH_SHORT).show();
        }

    }

}
