package com.kuliah.komsi.listviewapp;

public class ItemData {
    public String itemTitle;
    public String itemSubtitle;

}

