package com.kuliah.komsi.listviewapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ListView listView;
    private ArrayList<String> values;

    private ArrayList<ItemData> itemValues;
    private RecyclerView recyclerView;
    private ItemAdapter itemAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        listView = findViewById(R.id.listView);

        values = new ArrayList<>();
        for (int i=1; i<=10; i++){
            values.add("Item data - " + i);
        }

        itemValues = new ArrayList<>();
        for (int i=1; i<=10; i++){
            ItemData item = new ItemData();
            item.itemTitle = "Title Data - " + i;
            item.itemSubtitle = "Subtitle Data - " + i;
            itemValues.add(item);
        }

        itemAdapter = new ItemAdapter(this, itemValues);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        recyclerView.setAdapter(itemAdapter);

        /*ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.item_list,
                R.id.text1, values);
        listView.setAdapter(adapter);*/
    }

    public void addData(View view) {
        ItemData item = new ItemData();
        item.itemTitle = "Title Data - X";
        item.itemSubtitle = "Subtitle Data - X";

        itemValues.add(item);
        itemAdapter.notifyDataSetChanged();
    }
}
